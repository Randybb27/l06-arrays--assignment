﻿// See https://aka.ms/new-console-template for more information

// var tasklist = 0;

var option = "0";
while(option != "4") {
//  void displayOptions();
Console.WriteLine(@"
1. Create a Task
2. View All Task
3. Delete a Task
4. Quit
");

option = Console.ReadLine();


Console.WriteLine("Choose your task");
int num1 = 1;

switch (option)
{
    case "1":
        createTask(num1);
        break; 
    case "2":
        viewTask(num1);
        break;
    case "3":
        deleteTask(num1);
        break;
    case "4":
        Quit(num1);
        break;
}
}

void createTask (int num1){
    Console.WriteLine("What is the name of the task to create?");
    Console.ReadLine(num1 + "Has been added to the list");
}
void viewTask(int num1) {
    Console.WriteLine("");
}
void deleteTask(int num1) {
    Console.WriteLine("");
}
void Quit(int num1){
    Console.WriteLine("Goodbye");
}